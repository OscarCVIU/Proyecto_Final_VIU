package gui;

public interface Interfazgráfica {
}
import javafx.application.Application;
        import javafx.scene.Scene;
        import javafx.scene.control.*;
        import javafx.scene.layout.GridPane;
        import javafx.stage.Stage;

        import java.util.ArrayList;
        import java.util.List;

